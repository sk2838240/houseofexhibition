    <!-- Header Start -->
	<header class="main-header">
		<div class="header-sticky">
			<nav class="navbar navbar-expand-lg">
				<div class="container">
					<!-- Logo Start -->
					<a class="navbar-brand" href="index.php">
						<img src="images/logo.png" alt="Logo" style="width: 150px;">
					</a>
					<!-- Logo End -->

                    <!-- Main Menu Start -->
                    <div class="collapse navbar-collapse main-menu">
                        <div class="nav-menu-wrapper">
                            <ul class="navbar-nav mr-auto" id="menu">
                                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                                <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                                <li class="nav-item submenu"><a class="nav-link" href="#">Services Exhibition</a>
                                    <ul>
                                        <li class="nav-item"><a class="nav-link" href="#">Basic Stands</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#">Premium Stands</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#">Ultra Premium Stands</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                                <li class="nav-item"><a class="nav-link" href="#">Pay Online</a></li>
                                <li class="nav-item"><a class="nav-link" href="#">Carrer</a></li>
                            </ul>
                        </div>
                        
                        <!-- Header Btn Start -->
                        <div class="header-btn">
                            <a href="tel:+971523426256" class="btn-default btn-highlighted">
                                <i class="fa-solid fa-phone"></i> Get in Touch
                            </a>
                        </div>
                        <!-- Header Btn End -->
                    </div>
					<!-- Main Menu End -->
					<div class="navbar-toggle"></div>
				</div>
			</nav>
			<div class="responsive-menu"></div>
		</div>
	</header>
	<!-- Header End -->